package com.sakha.boot.model;



import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Employee {

@Id
@GeneratedValue
int id;
String empId;
String name;
float salary;
@DateTimeFormat(pattern="yyyy-MM-dd")
LocalDate dob;


public String getEmpId() {
	return empId;
}
public void setEmpId(String empId) {
	this.empId = empId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getSalary() {
	return salary;
}
public void setSalary(float salary) {
	this.salary = salary;
}
public LocalDate getDob() {
	return dob;
}
public void setDob(LocalDate dob) {
	this.dob = dob;
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(String name, float salary, LocalDate dob) {
	super();
	this.name = name;
	this.salary = salary;
	this.dob = dob;
}
@Override
public String toString() {
	return "Employee [Id=" + id + ", empId=" + empId + ", name=" + name + ", salary=" + salary + ", dob=" + dob + "]";
}




}
