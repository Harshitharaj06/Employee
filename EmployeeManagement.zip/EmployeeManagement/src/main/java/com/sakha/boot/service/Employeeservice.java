package com.sakha.boot.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sakha.boot.model.Employee;
import com.sakha.boot.repository.EmployeeRepo;

@Service
public class Employeeservice {

	@Autowired
	EmployeeRepo repo;
	
	public Employee registerEmp(Employee emp)
	{
		emp.setEmpId(generateId(emp.getName()));
		return repo.save(emp);
	}
	
	public List<Employee> getAllEmployee()
	{
		return repo.findAll();
	}
	
	public String generateId(String name)  {
		// TODO Auto-generated method stub
		String nameChar=name.substring(0,2);
		Random rand=new Random();
		int dgt=(int)(rand.nextDouble()*10000);
		return nameChar+dgt;
	}

	public Employee getemployeeId(String empId) {
		// TODO Auto-generated method stub
		return repo.getEmployeeById(empId);
	}

	public void deleteEmployee(Employee emp) 
	{
		Employee emp1=repo.getEmployeeById(emp.getEmpId());
		// TODO Auto-generated method stub
              repo.delete(emp1);
	}

   /*public Employee UpdateEmployee(Employee emp)
   {
	   return repo.
   }*/
	public Employee updateEmployee(Employee emp)
	{
		Employee uemp=repo.getEmployeeById(emp.getEmpId());
	    System.out.println(uemp);
	   // uemp.setName(emp.getName());
	   // uemp.setDob(emp.getDob());
	    uemp.setSalary(emp.getSalary());
	    return repo.save(uemp);
	    
	}

	
	

	
}
