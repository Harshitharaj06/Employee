package com.sakha.boot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.sakha.boot.model.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> {
	 @Query("from Employee where empId=:empId")
	public Employee getEmployeeById(String empId);
	 
	

	
}
