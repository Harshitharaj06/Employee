package com.sakha.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sakha.boot.model.Employee;
import com.sakha.boot.service.Employeeservice;
@Controller
public class EmployeeController 
{
    @Autowired
	Employeeservice service;
	@GetMapping("/")
	public String defaultpage()
	{
		return "index";
	}
	
	@PostMapping("/Register")
	public String save(@ModelAttribute Employee emp, Model m)
	{
		Employee saveemp=service.registerEmp(emp);
		m.addAttribute("emp",saveemp);
		return "view.jsp";
	}
	
	@PostMapping("/GetEmployee")
	public String getemployeeId(@RequestParam("empId") String empId, Model m)
	{
		Employee emp=service.getemployeeId(empId);
		m.addAttribute("e",emp);
		return "getemployee.jsp";
	}
	
	@PostMapping("/ViewAllEmployee")
	public String getAllEmploye(@ModelAttribute Employee emp,Model m)
	{
		List<Employee> emplist=service.getAllEmployee();
		m.addAttribute("emplist", emplist);
		return "getAllemployee.jsp";
	}

	@PostMapping("/delete")
	public void delete(@ModelAttribute Employee emp, Model m)
	{
		service.deleteEmployee(emp);
		m.addAttribute("emp","successful");
		//return "delete.jsp";
	}
	
	@PostMapping("/updateemployee")
	public String update(@ModelAttribute Employee emp, Model m)
	{
	Employee uemp1=service.updateEmployee(emp);
    m.addAttribute("emp",uemp1);
    return "update.jsp";
	}
}